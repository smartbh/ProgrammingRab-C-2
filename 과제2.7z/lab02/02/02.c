// Lab2-2 oddsum() �Լ�
#include <stdio.h>
void main()
{
}
